-- Some comment
local function some_func(txt)
    print(txt)
end

some_func("Hello World")
