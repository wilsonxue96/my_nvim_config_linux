# A comment
def some_method():
   print("This is a Python file")
