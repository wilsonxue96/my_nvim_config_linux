# A comment
def some_method
  puts "This is a Ruby file"
end
