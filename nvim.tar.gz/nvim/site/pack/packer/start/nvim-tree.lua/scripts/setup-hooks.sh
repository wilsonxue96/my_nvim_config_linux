#!/usr/bin/env bash

ln -sf ../../.hooks/pre-commit.sh .git/hooks/pre-commit
