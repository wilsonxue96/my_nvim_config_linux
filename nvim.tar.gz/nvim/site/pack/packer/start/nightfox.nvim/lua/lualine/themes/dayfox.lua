return require("nightfox.util.lualine")("dayfox")
