-- 基础设置
require("basic")
-- Packer 插件管理
require("plugins")
-- keybindings快捷键
require("keybindings")
-- nvim tree
require("nvim_tree")
